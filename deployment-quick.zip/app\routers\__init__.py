# Router module initialization
